<?php

namespace danog\MadelineProto\Ipc\Wrapper;

class SeekableOutputStream extends OutputStream
{
    use SeekableTrait;
}
